function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let farmerX = 100, farmerY = 300; // Posição do agricultor
let basketX = 100, basketY = 270; // Cesta de produtos agrícolas
let direction = 1; // Direção do movimento do agricultor
let balloons = []; // Array para armazenar balões
let fireworks = []; // Array para armazenar fogos de artifício

function setup() {
  createCanvas(800, 400);
  frameRate(30);
}

function draw() {
  background(220);

  // Desenha o campo e a cidade divididos
  drawCampo();
  drawCidade();

  // Desenha o agricultor e a cesta
  drawFarmer();
  drawBasket();

  // Movimenta o agricultor para a festa
  moveFarmer();

  // Efeitos de celebração
  spawnBalloons();
  drawBalloons();

  spawnFireworks();
  drawFireworks();
}

// Função para desenhar o campo (lado esquerdo)
function drawCampo() {
  fill(150, 200, 100); 
  rect(0, height - 50, width / 2, 50);  // Relva do campo
  
  fill(34, 139, 34);
  ellipse(100, 220, 60, 60); // Árvore no campo
  
  fill(255, 204, 0);
  ellipse(100, 100, 100, 100);  // Sol no céu

  // Plantação de vegetais
  fill(0, 255, 0);
  rect(200, 230, 40, 20);  // Plantação de trigo ou vegetais
  
  fill(255, 165, 0);
  rect(250, 230, 40, 20);  // Plantação de cenouras
  
  fill(255, 0, 0);
  ellipse(300, 250, 50, 50);  // Balão flutuante no campo
  
  fill(255, 223, 0);
  rect(250, 280, 20, 10); // Casa simples de fazenda
}

// Função para desenhar a cidade (lado direito)
function drawCidade() {
  fill(200, 200, 255);
  rect(width / 2, height - 50, width / 2, 50);  // Asfalto da cidade

  fill(50, 50, 50);
  rect(550, 150, 60, 200);  // Prédio na cidade

  fill(80, 80, 80);
  rect(650, 100, 60, 250);  // Outro prédio

  fill(255, 255, 0);
  ellipse(650, 100, 60, 60);  // Luz da cidade (Lua ou lâmpada da rua)
}

// Função para desenhar o agricultor
function drawFarmer() {
  fill(139, 69, 19);
  rect(farmerX, farmerY, 40, 40);  // Corpo do agricultor
  
  fill(255, 224, 189);
  ellipse(farmerX + 20, farmerY - 20, 25, 25);  // Cabeça do agricultor
  
  // Braços do agricultor (movendo como se estivesse celebrando)
  stroke(139, 69, 19);
  line(farmerX + 10, farmerY + 5, basketX, basketY);  // Braço esquerdo segurando a cesta
  line(farmerX + 30, farmerY + 5, basketX + 40, basketY); // Braço direito celebrando
}

// Função para desenhar a cesta de produtos agrícolas
function drawBasket() {
  fill(139, 69, 19);
  rect(basketX, basketY, 40, 20); // Cesta
  fill(255, 0, 0);
  ellipse(basketX + 10, basketY - 5, 10, 10); // Frutas na cesta
  ellipse(basketX + 30, basketY - 5, 10, 10); // Mais frutas na cesta
}

// Função para mover o agricultor (celebração)
function moveFarmer() {
  farmerX += direction * 3; // Movimento do agricultor

  // Se o agricultor atinge a borda da tela, muda de direção
  if (farmerX >= width / 2 - 50 || farmerX <= 0) {
    direction *= -1;
  }
}

// Funções para balões
function spawnBalloons() {
  if (frameCount % 10 === 0) {
    let balloon = {
      x: random(width / 2, width),
      y: height - 100,
      size: random(20, 40),
      speed: random(1, 2)
    };
    balloons.push(balloon);
  }
}

function drawBalloons() {
  for (let i = balloons.length - 1; i >= 0; i--) {
    let balloon = balloons[i];
    fill(random(255), random(255), random(255));
    ellipse(balloon.x, balloon.y, balloon.size, balloon.size);
    balloon.y -= balloon.speed;  // Os balões sobem

    // Remover balões que saíram da tela
    if (balloon.y < 0) {
      balloons.splice(i, 1);
    }
  }
}

// Funções para fogos de artifício
function spawnFireworks() {
  if (frameCount % 40 === 0) {
    let firework = {
      x: random(width / 2, width),
      y: height - 50,
      size: random(10, 20),
      speed: random(3, 6)
    };
    fireworks.push(firework);
  }
}

function drawFireworks() {
  for (let i = fireworks.length - 1; i >= 0; i--) {
    let firework = fireworks[i];
    fill(random(255), random(255), random(255));
    ellipse(firework.x, firework.y, firework.size, firework.size);
    firework.y -= firework.speed;  // Fogos de artifício subindo

    // Remover fogos que saíram da tela
    if (firework.y < 0) {
      fireworks.splice(i, 1);
    }
  }
}
